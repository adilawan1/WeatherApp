import "./App.css";
import Fetching from "./Components/Fetching";

function App() {
  return (
    <div className="App">
      <Fetching />
    </div>
  );
}

export default App;
